# Signa

Latest version with the enlarged signing space, full-body 3D avatar, common signs with fingerspelling fallback, and hand video export.

## Run locally

From this folder, run:

```sh
python3 -m http.server 8000 --directory dist
```

Open http://localhost:8000 in a modern browser. No build step is required. Serve the files over HTTP; do not open index.html directly.

The dist folder contains the complete web app and bundled dependencies. source-assets contains the source avatar assets. Third-party licenses are included in dist/vendor.

This is a signing prototype; motions need fluent-signer review and it is not a full ASL translation system.
