# Aware UI/UX update

Based on `android-native` commit `bccfd2c56670e20d19af2cfb9e6407cfff72a702`.

## Interface changes

- Pale blue/mint background, soft white cards, circular colored icon wells, compact typography, and floating capsule dock inspired by the supplied health-app reference.
- One microphone icon for the existing listening toggle; no visible dB meter or level bars.
- Compact summary preview, icon refresh action, and a full-text summary sheet.
- Surroundings shows two distinct recent sounds initially and at most five after Show more. Sound details and existing vibration replay remain available.
- One CC entry to the existing Live Talk screen.
- Light rounded signer panel above large live transcription. Existing active-word highlighting is recolored for the light surface.
- Grouped Settings and matching permission entry styling.
- Vibration testing/raw diagnostics are tucked behind developer controls in debug builds. Raw display is capped at four labels and sampled every two seconds; normal alerts are not sampled.
- Dedicated emergency theme preserves large, high-contrast emergency presentation.

## Functional scope

All 37 source files in audio, classify, alert, haptics, speech, llm, service, and data packages are byte-for-byte identical to the cloned branch. `HomeViewModel`, `CaptionBatcher`, `AvatarWebView`, sign vocabulary, rigging, playback queue, and model/animation code are unchanged. The embedded avatar page changes only its CSS backing from black to transparent. No summary-trigger changes, audio changes, new cloud APIs, or new application dependencies are included.

`HomePresentation.kt` only projects existing data for display. It caps/deduplicates the small Home preview without changing the underlying feed. The source detector still receives its original full label set.

## Open the project

Open this folder in Android Studio. Use the existing README for JDK/SDK prerequisites and optional on-device model setup. The archive includes the original YAMNet asset downloaded by the existing setup script, so that setup step will skip the already-present file. No optional LLM model is bundled.

The source archive excludes `.git`, Gradle/build caches, generated APKs, temporary verification harnesses, and machine-specific SDK paths.

## Preview images

`docs/ui-previews/` contains actual Compose renders from a temporary Android/Robolectric graphics harness, using deterministic preview data. These are design previews, not recordings of live sound detections. They cover listening, paused, expanded Surroundings, Settings, and a compact screen with 200% text scaling.

`docs/UI_DESIGN_PLAN.md` contains the full reference and UI planning specification.

## Verification

Clean debug build and all 71 project unit tests passed. Lint passed with no errors (52 warnings). Four native UI checks, seven JavaScript tests, and the adapted avatar runtime check passed. See `docs/VALIDATION.md` for methods and limitations.
