# UI previews

These PNGs render the updated native Compose components with fixed test data.

- `home-listening.png`: listening hero, summary, and two sound rows.
- `home-expanded.png`: Show more interaction and additional surrounding sounds.
- `home-paused.png`: stopped/empty state.
- `home-large-text.png`: 320 dp wide compact screen with 200% text scale.
- `settings.png`: existing sound toggles in the new grouped layout.

Images were visually inspected. They do not substitute for testing on your physical phone, particularly its speech recognizer and WebView.
