# Validation of the UI update

Base: android-native commit bccfd2c56670e20d19af2cfb9e6407cfff72a702.

- Clean debug build: PASS.
- Project JVM unit tests: 71 passed, 0 failures, 0 errors. Includes the existing 67 tests and four UI-presentation regression tests.
- Android lint: PASS, no errors; 52 warnings remain.
- Existing JavaScript caption/sign tests: seven passed using Node 24 (`node --test scripts/test_avatar_sync.mjs`).
- Native Compose/Robolectric graphics checks: four passed using a temporary external harness. Checks cover listening/paused Home, microphone callback, Surroundings expansion, Settings, and 320 dp width at 200% text scale.
- Avatar WebGL runtime: PASS using the unchanged assets with their new transparent page backing. The temporary Linux runner adapts the existing smoke script's Windows-only path-separator check and browser executable; the shipped script is unchanged. Model loading, ordered signs, bridge callbacks, deduplication, and clear/cancel passed.
- Source-scope audit: all 37 functional source files in audio/classify/alert/haptics/speech/llm/service/data are byte-for-byte unchanged. The native avatar bridge, caption batcher, HomeViewModel, dependencies, and manifest are unchanged.

Final clean command:

```sh
./gradlew :app:clean :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

The temporary rendering harness, downloaded SDK/JDK/browser, build caches, and generated APK are excluded from this source archive. Rendered test-data previews are in docs/ui-previews. A physical Android device was not available for this verification; existing connected-device tests remain included for the user's device workflow.
