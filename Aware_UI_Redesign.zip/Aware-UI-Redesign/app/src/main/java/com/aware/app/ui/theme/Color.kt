package com.aware.app.ui.theme

import androidx.compose.ui.graphics.Color

val AwareBackground = Color(0xFFF5F6F5)
val AwareSurface = Color(0xFFFFFFFF)
val AwareAccent = Color(0xFF50CC38)
val AwareAction = Color(0xFF2F7D26)
val AwareInk = Color(0xFF171C20)
val AwareSecondary = Color(0xFF657071)
val AwareSky = Color(0xFFDCEFF1)
val AwareMint = Color(0xFFE7F3E9)
val AwareInset = Color(0xFFF1F3F1)

object CategoryColors {
    val EMERGENCY = Color(0xFFD63838)
    val TRAFFIC = Color(0xFFE5793F)
    val HOME = Color(0xFF19ADD8)
    val PEOPLE = Color(0xFF48B936)
    val ANIMALS = Color(0xFFA477D5)
}
