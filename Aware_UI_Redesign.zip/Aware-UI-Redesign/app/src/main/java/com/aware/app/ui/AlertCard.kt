package com.aware.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aware.app.R
import com.aware.app.alert.AlertMessages
import com.aware.app.alert.Detection
import com.aware.app.llm.Summary
import com.aware.app.ui.theme.*
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun AlertCard(
    detection: Detection, nowMs: Long, onReplay: () -> Unit, modifier: Modifier = Modifier,
    situation: Summary? = null, situationTimeMs: Long = 0L,
) {
    val context = LocalContext.current
    val messages = remember(context) { AlertMessages(context::getString) }
    var expanded by rememberSaveable(detection.timeMs, detection.type) { mutableStateOf(false) }
    SoftCard(modifier.semantics { liveRegion = LiveRegionMode.Polite }, accent = categoryColor(detection.type.category)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 16.dp, end = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconWell(soundArtwork(detection.type), categoryColor(detection.type.category))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(soundName(detection.type), style = MaterialTheme.typography.titleMedium)
                Text(messages.templateFor(detection), style = MaterialTheme.typography.bodyMedium, color = AwareSecondary)
            }
            SoftIconButton(Icons.Default.Vibration,
                stringResource(R.string.ui_replay_sound, soundName(detection.type)), onReplay)
        }
        Row(Modifier.fillMaxWidth().padding(start = 76.dp, end = 12.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(timeAgo(detection.timeMs, nowMs), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = AwareSecondary)
            TextButton(onClick = { expanded = !expanded }) {
                Text(stringResource(if (expanded) R.string.ui_show_less else R.string.ui_details))
            }
        }
        if (expanded) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HorizontalDivider(color = AwareInset)
                Text(trendText(detection.trend), style = MaterialTheme.typography.bodyMedium)
                Text(stringResource(R.string.home_score, (detection.score.coerceIn(0f, 1f) * 100).roundToInt()),
                    style = MaterialTheme.typography.bodyMedium, color = AwareSecondary)
                if (situation != null && abs(situationTimeMs - detection.timeMs) <= 15_000L) {
                    Text(situation.text, style = MaterialTheme.typography.bodyMedium)
                }
                Text(stringResource(R.string.alert_replay_hint), style = MaterialTheme.typography.bodySmall, color = AwareSecondary)
            }
        }
    }
}
