package com.aware.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AwareLightColors = lightColorScheme(
    primary = AwareAction, onPrimary = Color.White,
    primaryContainer = Color(0xFFE1F5DB), onPrimaryContainer = Color(0xFF163611),
    secondary = Color(0xFF237F94), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE1F4FA), onSecondaryContainer = AwareInk,
    tertiary = Color(0xFF9B4470),
    background = AwareBackground, onBackground = AwareInk,
    surface = AwareSurface, onSurface = AwareInk,
    surfaceVariant = AwareInset, onSurfaceVariant = AwareSecondary,
    error = Color(0xFFB3261E), onError = Color.White,
    outline = Color(0xFFABB7AC), outlineVariant = Color(0xFFE1E8E1),
    surfaceTint = Color.Transparent,
)

// Preserve the existing large, high-contrast emergency presentation.
private val EmergencyColors = darkColorScheme(
    primary = Color(0xFFDAFF62), onPrimary = Color(0xFF080A0C),
    primaryContainer = Color(0xFF303E00), onPrimaryContainer = Color.White,
    secondary = Color(0xFF80CBC4),
    background = Color(0xFF080A0C), onBackground = Color.White,
    surface = Color(0xFF111418), onSurface = Color.White,
    surfaceVariant = Color(0xFF252A30), onSurfaceVariant = Color.White,
    error = Color(0xFFFF6B6B), onError = Color(0xFF080A0C),
)

@Composable
fun AwareTheme(emergency: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (emergency) EmergencyColors else AwareLightColors,
        typography = if (emergency) AwareEmergencyTypography else AwareTypography,
        content = content,
    )
}
