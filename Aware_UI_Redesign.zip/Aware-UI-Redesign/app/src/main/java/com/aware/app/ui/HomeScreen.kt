package com.aware.app.ui

import android.content.pm.ApplicationInfo
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aware.app.R
import com.aware.app.alert.Category
import com.aware.app.alert.SoundType
import com.aware.app.alert.Trend
import com.aware.app.llm.Source
import com.aware.app.llm.Summary
import com.aware.app.service.FeedItem
import com.aware.app.ui.theme.*
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.sample
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel(),
    onTestHaptics: () -> Unit = {},
    onSettings: () -> Unit = {},
    onCaptions: () -> Unit = {},
) {
    // UI projections exclude inference-rate level/label churn from normal dashboard state.
    val presentation = remember(viewModel) { viewModel.state.map { it.homeFrame() }.distinctUntilChanged() }
    val initialFrame = remember(viewModel) { viewModel.state.value.homeFrame() }
    val frame by presentation.collectAsStateWithLifecycle(initialValue = initialFrame)
    val running by viewModel.running.collectAsStateWithLifecycle()
    val situation by viewModel.situation.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current
    val now by produceState(System.currentTimeMillis(), running, owner) {
        if (running) owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) { value = System.currentTimeMillis(); delay(1_000) }
        }
    }
    val debugBuild = LocalContext.current.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
    HomeContent(
        modifier = modifier, frame = frame, running = running, summary = situation, nowMs = now,
        onToggle = viewModel::toggleListening, onRefresh = viewModel::requestSituation,
        onSettings = onSettings, onCaptions = onCaptions,
        onReplay = viewModel::replayAlert, onReplayName = viewModel::replayName,
        debugContent = if (debugBuild) ({ RawLabelsPanel(viewModel, onTestHaptics) }) else null,
    )
}

@Composable
internal fun HomeContent(
    frame: HomeFrame,
    running: Boolean,
    summary: Summary?,
    nowMs: Long,
    modifier: Modifier = Modifier,
    onToggle: () -> Unit = {},
    onRefresh: () -> Unit = {},
    onSettings: () -> Unit = {},
    onCaptions: () -> Unit = {},
    onReplay: (SoundType) -> Unit = {},
    onReplayName: () -> Unit = {},
    debugContent: (@Composable () -> Unit)? = null,
) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    var showSummary by rememberSaveable { mutableStateOf(false) }
    var showDebug by rememberSaveable { mutableStateOf(false) }
    var selectedSound by remember { mutableStateOf<FeedItem?>(null) }
    val rows = remember(frame.feed) { surroundingRows(frame.feed) }
    val visibleRows = if (expanded) rows else rows.take(2)
    val heroSpacing = if (LocalConfiguration.current.fontScale > 1.35f) 12.dp else (-12).dp
    AwareBackdrop(modifier) {
        Box(Modifier.fillMaxSize().safeDrawingPadding()) {
            Column(Modifier.fillMaxSize()) {
                AwareHeader(stringResource(R.string.app_name), Modifier.padding(horizontal = 16.dp),
                    leading = { SoftIconButton(Icons.Default.AutoAwesome, stringResource(R.string.ui_refresh_summary), onRefresh, enabled = running) },
                    trailing = { SoftIconButton(Icons.Default.Settings, stringResource(R.string.settings_title), onSettings) })
                LazyColumn(
                    Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item(key = "listening") {
                        Column(verticalArrangement = Arrangement.spacedBy(heroSpacing)) {
                            ListeningHero(running, frame.alertsPaused, onToggle)
                            SummaryPreview(summary, running, onOpen = { showSummary = true })
                        }
                    }
                    if (frame.alertsPaused) item(key = "paused-alerts") {
                        SoftCard(accent = CategoryColors.TRAFFIC) {
                            Text(stringResource(R.string.ui_monitoring_paused), Modifier.padding(16.dp),
                                color = AwareSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    frame.error?.let { error -> item(key = "error") {
                        SoftCard(accent = CategoryColors.EMERGENCY) {
                            Text(stringResource(R.string.home_error, error),
                                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.padding(16.dp).semantics { liveRegion = LiveRegionMode.Assertive })
                        }
                    } }
                    val nameTime = frame.latestNameAlertMs
                    if (nameTime != null && (frame.latestAlert == null || nameTime > frame.latestAlert.timeMs)) {
                        item(key = "latest-name") {
                            Column {
                                SectionHeading(stringResource(R.string.ui_last_alert))
                                SoftCard(accent = CategoryColors.PEOPLE, onClick = onReplayName) {
                                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        IconWell(Icons.Default.Person, CategoryColors.PEOPLE)
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(stringResource(R.string.alert_name_called), style = MaterialTheme.typography.titleMedium)
                                            Text(timeAgo(nameTime, nowMs), color = AwareSecondary, style = MaterialTheme.typography.bodySmall)
                                            Text(stringResource(R.string.alert_replay_hint), color = AwareAction, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Icon(Icons.Default.Vibration, null, Modifier.size(20.dp), tint = AwareSecondary)
                                    }
                                }
                            }
                        }
                    } else frame.latestAlert?.let { alert -> item(key = "latest-alert") {
                        Column {
                            SectionHeading(stringResource(R.string.ui_last_alert))
                            AlertCard(alert, nowMs, onReplay = { onReplay(alert.type) })
                        }
                    } }
                    item(key = "surroundings-heading") {
                        SectionHeading(
                            stringResource(R.string.ui_surroundings),
                            if (rows.size > 2) stringResource(if (expanded) R.string.ui_show_less else R.string.ui_show_more) else null,
                            onAction = { expanded = !expanded },
                        )
                    }
                    if (visibleRows.isEmpty()) item(key = "empty-surroundings") {
                        SoftCard {
                            Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconWell(Icons.Default.Hearing, AwareAccent)
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(stringResource(R.string.ui_quiet_title), style = MaterialTheme.typography.titleMedium)
                                    Text(stringResource(if (running) R.string.ui_quiet_body else R.string.home_start_hint),
                                        color = AwareSecondary, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    items(visibleRows, key = { if (it.nameCalled) "name-called" else it.type.name }) { item ->
                        SurroundingRow(item, nowMs, onClick = { selectedSound = item })
                    }
                    if (debugContent != null) {
                        item(key = "debug-toggle") {
                            TextButton(onClick = { showDebug = !showDebug }) {
                                Text(stringResource(if (showDebug) R.string.home_debug_hide else R.string.ui_open_developer))
                            }
                        }
                        if (showDebug) item(key = "debug-labels") { debugContent() }
                    }
                }
            }
            DockFade(Modifier.align(Alignment.BottomCenter))
            AwareDock(DockPage.Home, onHome = {}, onCaptions = onCaptions,
                onSummary = { showSummary = true }, onSettings = onSettings,
                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 24.dp, vertical = 12.dp))
        }
    }
    if (showSummary) CurrentSummarySheet { showSummary = false }
    selectedSound?.let { sound ->
        val title = if (sound.nameCalled) stringResource(R.string.alert_name_called) else soundName(sound.type)
        AlertDialog(
            onDismissRequest = { selectedSound = null },
            icon = { IconWell(soundArtwork(sound.type, sound.nameCalled), categoryColor(sound.type.category)) },
            title = { Text(title) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(timeAgo(sound.timeMs, nowMs))
                sound.text?.let { Text(it) }
                Text(trendText(sound.trend))
            } },
            confirmButton = { TextButton(onClick = { selectedSound = null }) { Text(stringResource(R.string.ui_done)) } },
            dismissButton = {
                if (sound.nameCalled || sound.type.alerts) TextButton(onClick = {
                    if (sound.nameCalled) onReplayName() else onReplay(sound.type)
                }) { Text(stringResource(R.string.ui_replay)) }
            },
            containerColor = AwareSurface,
        )
    }
}

@Composable
private fun SurroundingRow(item: FeedItem, nowMs: Long, onClick: () -> Unit) {
    SoftCard(accent = categoryColor(item.type.category), onClick = onClick) {
        Row(Modifier.fillMaxWidth().heightIn(min = 76.dp).padding(horizontal = 15.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconWell(soundArtwork(item.type, item.nameCalled), categoryColor(item.type.category))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (item.nameCalled) stringResource(R.string.alert_name_called) else soundName(item.type),
                    style = MaterialTheme.typography.titleMedium)
                Text(timeAgo(item.timeMs, nowMs), style = MaterialTheme.typography.bodyMedium, color = AwareSecondary)
            }
            TrailingArrow()
        }
    }
}

@Composable
private fun RawLabelsPanel(viewModel: HomeViewModel, onTestHaptics: () -> Unit) {
    val running by viewModel.running.collectAsStateWithLifecycle()
    SettingsGroup(stringResource(R.string.ui_developer_tools)) {
        Text(stringResource(R.string.ui_raw_labels_hint), color = AwareSecondary, style = MaterialTheme.typography.bodySmall)
        // Leaving this branch discards its sampled state immediately on stop.
        if (running) LiveRawLabelRows(viewModel)
        TextButton(onClick = onTestHaptics) { Text(stringResource(R.string.home_test_haptics)) }
    }
}

@OptIn(FlowPreview::class)
@Composable
private fun LiveRawLabelRows(viewModel: HomeViewModel) {
    val labelFlow = remember(viewModel) { viewModel.state.map { it.labels.take(4) }.sample(2_000).distinctUntilChanged() }
    val labels by labelFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    labels.forEach { label ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label.name, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${(label.score.coerceIn(0f, 1f) * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium, color = AwareSecondary)
        }
    }
    if (labels.isEmpty()) Text(stringResource(R.string.ui_empty_labels), style = MaterialTheme.typography.bodyMedium)
}

@Preview(name = "Aware · listening", widthDp = 390, heightDp = 844, showBackground = true)
@Composable
private fun HomeListeningPreview() {
    AwareTheme {
        HomeContent(HomeFrame(null, null, listOf(
            FeedItem(9_000, SoundType.DOORBELL, 0.9f, Trend.STEADY),
            FeedItem(7_000, SoundType.SPEECH, 0.8f, Trend.STEADY),
            FeedItem(5_000, SoundType.DOG_BARK, 0.8f, Trend.STEADY),
        ), false, null), true, Summary("A doorbell was heard nearby.", Source.TEMPLATE), 10_000)
    }
}

@Preview(name = "Aware · paused", widthDp = 390, heightDp = 844, showBackground = true)
@Composable
private fun HomePausedPreview() {
    AwareTheme { HomeContent(HomeFrame(null, null, emptyList(), false, null), false, null, 0) }
}
