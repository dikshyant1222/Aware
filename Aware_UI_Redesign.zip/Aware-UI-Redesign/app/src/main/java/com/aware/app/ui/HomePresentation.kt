package com.aware.app.ui

import com.aware.app.alert.Detection
import com.aware.app.service.FeedItem
import com.aware.app.service.PipelineState

/** Presentation projection: raw inference/level changes do not recompose the dashboard. */
internal data class HomeFrame(
    val error: String?,
    val latestAlert: Detection?,
    val feed: List<FeedItem>,
    val alertsPaused: Boolean,
    val latestNameAlertMs: Long?,
)

internal fun PipelineState.homeFrame() = HomeFrame(
    error,
    // The level is not displayed. Normalize only this UI copy, never the source detection.
    latestAlert?.copy(levelDb = 0f),
    feed,
    alertsPaused,
    latestNameAlertMs,
)

/** Keep the source feed intact. The compact preview shows the newest five distinct kinds. */
internal fun surroundingRows(feed: List<FeedItem>): List<FeedItem> =
    feed.sortedByDescending { it.timeMs }
        .distinctBy { if (it.nameCalled) "name-called" else it.type.name }
        .take(5)
