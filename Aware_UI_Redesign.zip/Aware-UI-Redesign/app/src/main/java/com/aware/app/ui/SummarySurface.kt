package com.aware.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aware.app.R
import com.aware.app.llm.Source
import com.aware.app.llm.Summary
import com.aware.app.service.ListeningRepository
import com.aware.app.ui.theme.*

@Composable
internal fun SummaryPreview(summary: Summary?, running: Boolean, onOpen: () -> Unit) {
    SoftCard(onClick = onOpen) {
        Row(Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconWell(Icons.Default.AutoAwesome, AwareAccent)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.ui_summary), style = MaterialTheme.typography.titleMedium)
                Text(summary?.text ?: stringResource(if (running) R.string.ui_summary_empty else R.string.ui_summary_stopped),
                    style = MaterialTheme.typography.bodyMedium, color = AwareSecondary,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp), tint = AwareSecondary)
        }
    }
}

/** Reads the existing summary. Opening the sheet does not change generation policy. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CurrentSummarySheet(onDismiss: () -> Unit) {
    val summary by ListeningRepository.situation.collectAsStateWithLifecycle()
    val updated by ListeningRepository.situationTimeMs.collectAsStateWithLifecycle()
    val running by ListeningRepository.running.collectAsStateWithLifecycle()
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AwareSurface) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconWell(Icons.Default.AutoAwesome, AwareAccent)
                Text(stringResource(R.string.ui_summary), Modifier.weight(1f).padding(start = 14.dp),
                    style = MaterialTheme.typography.headlineSmall)
                SoftIconButton(Icons.Default.Refresh, stringResource(R.string.ui_refresh_summary),
                    onClick = ListeningRepository::requestSituation, enabled = running)
            }
            Text(summary?.text ?: stringResource(if (running) R.string.ui_summary_empty else R.string.ui_summary_stopped),
                style = MaterialTheme.typography.headlineSmall)
            if (summary != null) {
                Text(stringResource(if (summary?.source == Source.LLM) R.string.situation_ai else R.string.situation_template),
                    color = AwareSecondary, style = MaterialTheme.typography.bodyMedium)
                if (updated > 0) Text(timeAgo(updated, System.currentTimeMillis()), color = AwareSecondary,
                    style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text(stringResource(R.string.ui_done)) }
        }
    }
}
