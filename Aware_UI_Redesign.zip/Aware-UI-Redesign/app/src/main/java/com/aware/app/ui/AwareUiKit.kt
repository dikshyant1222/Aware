package com.aware.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aware.app.R
import com.aware.app.ui.theme.*

@Composable
internal fun AwareBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val gradientEnd = with(density) { 390.dp.toPx() }
    Box(
        modifier.fillMaxSize().background(
            Brush.verticalGradient(
                0f to AwareSky, 0.32f to AwareMint,
                0.65f to Color(0xFFF0F5EF), 1f to AwareBackground,
                endY = gradientEnd,
            ),
        ),
        content = content,
    )
}

@Composable
internal fun SoftIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tint: Color = AwareInk,
) {
    Box(
        modifier.size(48.dp).clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(44.dp)
                .shadow(5.dp, CircleShape, ambientColor = Color(0x0C24392C), spotColor = Color(0x0C24392C))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.92f), Color.White.copy(alpha = 0.60f))), CircleShape)
                .border(1.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, Modifier.size(22.dp), tint = if (enabled) tint else AwareSecondary.copy(alpha = 0.45f))
        }
    }
}

@Composable
internal fun AwareHeader(
    title: String,
    modifier: Modifier = Modifier,
    leading: @Composable () -> Unit = {},
    trailing: @Composable () -> Unit = {},
) {
    Box(modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Box(Modifier.align(Alignment.CenterStart)) { leading() }
        Text(title, Modifier.align(Alignment.Center).padding(horizontal = 60.dp),
            style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box(Modifier.align(Alignment.CenterEnd)) { trailing() }
    }
}

@Composable
internal fun IconWell(icon: ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Box(
        modifier.size(46.dp)
            .shadow(5.dp, CircleShape, ambientColor = Color(0x10243A29), spotColor = Color(0x10243A29))
            .background(Brush.verticalGradient(listOf(Color.White, accent.copy(alpha = 0.16f))), CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, Modifier.size(24.dp), tint = accent)
    }
}

@Composable
internal fun TrailingArrow() {
    Box(Modifier.size(36.dp).shadow(4.dp, CircleShape,
        ambientColor = Color(0x0A24392C), spotColor = Color(0x0A24392C))
        .background(Color.White.copy(alpha = 0.8f), CircleShape).border(1.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center) {
        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(19.dp), tint = AwareInk)
    }
}

@Composable
internal fun SoftCard(
    modifier: Modifier = Modifier,
    accent: Color = Color.White,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    Surface(
        modifier = modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clip(shape).clickable(role = Role.Button, onClick = onClick) else Modifier),
        color = Color.White.copy(alpha = 0.86f),
        shape = shape,
        border = BorderStroke(1.dp, if (accent == Color.White) Color.White else accent.copy(alpha = 0.14f)),
        shadowElevation = 1.dp,
        tonalElevation = 0.dp,
    ) { Column(content = content) }
}

@Composable
internal fun SectionHeading(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        if (action != null) {
            Box(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                .clickable(role = Role.Button, onClick = onAction).padding(start = 12.dp), contentAlignment = Alignment.Center) {
                Text(action, color = AwareAction, style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.drawBehind {
                        drawLine(AwareAction, Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f),
                            strokeWidth = 1.2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.dp.toPx(), 2.dp.toPx())))
                    })
            }
        }
    }
}

@Composable
internal fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(AwareInset).padding(6.dp)) {
        Text(title, Modifier.padding(horizontal = 12.dp, vertical = 12.dp), style = MaterialTheme.typography.titleMedium)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color.White).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
    }
}

internal enum class DockPage { Home, Settings }

@Composable
internal fun AwareDock(
    selected: DockPage,
    onHome: () -> Unit,
    onCaptions: () -> Unit,
    onSummary: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val compactLabels = LocalConfiguration.current.fontScale > 1.35f
    Row(
        modifier.widthIn(max = 300.dp).fillMaxWidth().heightIn(min = 60.dp)
            .shadow(12.dp, CircleShape, ambientColor = Color(0x10313F33), spotColor = Color(0x10313F33))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.96f), Color.White.copy(alpha = 0.77f))), CircleShape)
            .border(1.dp, Color.White, CircleShape).padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        @Composable
        fun RowScope.Item(icon: ImageVector, label: String, active: Boolean, action: () -> Unit) {
            Row(
                Modifier.weight(if (active && !compactLabels) 1.65f else 1f)
                    .heightIn(min = 52.dp).clip(CircleShape)
                    .background(if (active) Color(0xFFDEDEDE) else Color.Transparent)
                    .clickable(role = Role.Button, onClick = action)
                    .semantics { contentDescription = label; this.selected = active }
                    .padding(horizontal = 7.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, Modifier.size(21.dp), tint = if (active) AwareInk else Color(0xFF929A96))
                if (active && !compactLabels) {
                    Spacer(Modifier.width(6.dp))
                    Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Item(Icons.Default.Home, stringResource(R.string.ui_home), selected == DockPage.Home, onHome)
        Item(Icons.Default.ClosedCaption, stringResource(R.string.ui_live_talk), false, onCaptions)
        Item(Icons.Default.AutoAwesome, stringResource(R.string.ui_summary), false, onSummary)
        Item(Icons.Default.Settings, stringResource(R.string.settings_title), selected == DockPage.Settings, onSettings)
    }
}

@Composable
internal fun DockFade(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(104.dp).background(
        Brush.verticalGradient(listOf(Color.Transparent, AwareBackground.copy(alpha = 0.94f), AwareBackground)),
    ))
}
