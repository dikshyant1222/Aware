package com.aware.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aware.app.R
import com.aware.app.ui.theme.*

@Composable
internal fun ListeningHero(running: Boolean, alertsPaused: Boolean, onToggle: () -> Unit) {
    val active = running && !alertsPaused
    val description = stringResource(if (running) R.string.home_stop_listening else R.string.home_start_listening)
    Box(Modifier.fillMaxWidth().heightIn(min = 152.dp), contentAlignment = Alignment.TopCenter) {
        Canvas(Modifier.width(284.dp).height(166.dp)) {
            val stroke = 22.dp.toPx()
            val diameter = size.width - stroke
            val origin = Offset(stroke / 2, 12.dp.toPx())
            drawArc(Color(0xFFE5ECE5), 180f, 180f, false,
                topLeft = origin.copy(y = origin.y + 3.dp.toPx()), size = Size(diameter, diameter),
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Brush.linearGradient(listOf(Color.White, Color(0xFFF9FCF8))), 180f, 180f, false,
                topLeft = origin, size = Size(diameter, diameter), style = Stroke(stroke, cap = StrokeCap.Round))
            if (active) {
                // A fixed state accent, deliberately unrelated to RMS, scores, or progress.
                drawArc(Brush.linearGradient(listOf(AwareAccent, Color(0xFF8ADD6C))), 184f, 30f, false,
                    topLeft = origin, size = Size(diameter, diameter), style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        Column(Modifier.padding(top = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(72.dp).shadow(8.dp, CircleShape,
                    ambientColor = Color(0x10273C28), spotColor = Color(0x10273C28))
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color.White, if (active) Color(0xFFE0F6D9) else Color(0xFFF3F5F3))))
                    .border(1.dp, Color.White, CircleShape)
                    .clickable(role = Role.Button, onClick = onToggle)
                    .semantics { contentDescription = description },
                contentAlignment = Alignment.Center,
            ) {
                Icon(if (running) Icons.Default.Mic else Icons.Default.MicOff, null,
                    Modifier.size(30.dp), tint = if (active) AwareAction else AwareSecondary)
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(if (running) R.string.home_listening else R.string.ui_paused),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
        }
    }
}
