package com.aware.app.ui

import com.aware.app.alert.SoundType
import com.aware.app.alert.Trend
import com.aware.app.alert.Detection
import com.aware.app.service.FeedItem
import com.aware.app.service.PipelineState
import com.aware.app.classify.Label
import org.junit.Assert.*
import org.junit.Test

class HomePresentationTest {
    private fun sound(type: SoundType, time: Long, name: Boolean = false) =
        FeedItem(time, type, .8f, Trend.STEADY, nameCalled = name)

    @Test fun recentPreviewKeepsNewestOccurrenceWithoutMutatingFeed() {
        val feed = listOf(sound(SoundType.DOORBELL, 1), sound(SoundType.DOG_BARK, 3), sound(SoundType.DOORBELL, 5))
        val snapshot = feed.toList()
        assertEquals(listOf(5L, 3L), surroundingRows(feed).map { it.timeMs })
        assertEquals(snapshot, feed)
    }

    @Test fun expandedPreviewCapsAtFiveDistinctSounds() {
        val feed = SoundType.entries.mapIndexed { index, type -> sound(type, index.toLong()) }
        val rows = surroundingRows(feed)
        assertEquals(5, rows.size)
        assertEquals(feed.last().timeMs, rows.first().timeMs)
        assertEquals(5, rows.map { it.type }.distinct().size)
    }

    @Test fun nameCalledDoesNotDisappearIntoOrdinarySpeech() {
        val rows = surroundingRows(listOf(sound(SoundType.SPEECH, 1), sound(SoundType.SPEECH, 2, name = true)))
        assertEquals(2, rows.size)
        assertTrue(rows.first().nameCalled)
        assertFalse(rows.last().nameCalled)
    }

    @Test fun rawInferenceChangesDoNotInvalidateNormalDashboardPresentation() {
        val detection = Detection(SoundType.DOORBELL, .9f, Trend.STEADY, -40f, 1, true)
        val before = PipelineState(listening = true, labels = listOf(Label("Speech", .8f)), levelDb = -40f, latestAlert = detection)
        val next = before.copy(labels = listOf(Label("Speech", .9f)), levelDb = -20f, latestAlert = detection.copy(levelDb = -20f))
        assertEquals(before.homeFrame(), next.homeFrame())
        assertEquals(-40f, before.latestAlert!!.levelDb)
        assertNotEquals(before.homeFrame(), next.copy(error = "Microphone unavailable").homeFrame())
    }
}
